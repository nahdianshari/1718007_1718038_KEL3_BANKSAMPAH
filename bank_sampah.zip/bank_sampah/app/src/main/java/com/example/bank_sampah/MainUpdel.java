package com.example.bank_sampah;

import android.app.Activity;

public class MainUpdel extends Activity {
}
